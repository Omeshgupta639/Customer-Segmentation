#!/usr/bin/env bash
# Rebuild everything from scratch: data -> segmentation -> charts -> report
set -e
cd "$(dirname "$0")/.."
python scripts/01_generate_data.py
python scripts/02_segmentation.py "$@"
