"""
Step 1: generate a realistic, synthetic retail dataset.

Creates two files in data/raw/:
  customers.csv     one row per customer (demographics)
  transactions.csv  one row per purchase

The data is simulated because real customer data is private. It is built from
five hidden behaviour groups (with deliberate overlap between them) so that the
clustering has real structure to find without being trivially easy.
The hidden group is NOT written to the files, so the model never sees it
(it is only stored separately in data/raw/_ground_truth.csv for one validation
check at the end of the analysis).

Run:  python scripts/01_generate_data.py
"""
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
RAW = ROOT / "data" / "raw"
RAW.mkdir(parents=True, exist_ok=True)

rng = np.random.default_rng(7)
N_CUSTOMERS = 3000
SNAPSHOT = pd.Timestamp("2025-12-31")  # "today" for the analysis
CATS = ["Electronics", "Fashion", "Home & Kitchen", "Beauty", "Sports & Fitness", "Grocery"]

# Hidden behaviour groups (used only to simulate data)
G = {
    "champions": dict(share=.16, age=(40, 8, 25, 65), inc=(1_400_000, 350_000, 600_000, 3_000_000),
                      n_orders=lambda: rng.poisson(24) + 6, rec_scale=12, aov=3500,
                      disc=.15, online=.60, ret=.04, loyal=.80, tier=[.55, .30, .15],
                      cats=[.25, .20, .20, .10, .15, .10]),
    "deal_seekers": dict(share=.26, age=(24, 4, 18, 35), inc=(350_000, 100_000, 150_000, 700_000),
                         n_orders=lambda: rng.poisson(14) + 3, rec_scale=25, aov=900,
                         disc=.65, online=.85, ret=.12, loyal=.30, tier=[.30, .40, .30],
                         cats=[.10, .30, .08, .22, .15, .15]),
    "premium_occasional": dict(share=.14, age=(50, 8, 35, 70), inc=(2_000_000, 500_000, 900_000, 4_000_000),
                               n_orders=lambda: rng.poisson(4) + 2, rec_scale=60, aov=9000,
                               disc=.08, online=.30, ret=.05, loyal=.40, tier=[.65, .25, .10],
                               cats=[.40, .10, .30, .05, .10, .05]),
    "lapsed": dict(share=.22, age=(42, 12, 22, 70), inc=(800_000, 300_000, 250_000, 2_000_000),
                   n_orders=lambda: rng.poisson(8) + 3, rec_scale=None, aov=2000,
                   disc=.30, online=.50, ret=.08, loyal=.35, tier=[.40, .35, .25],
                   cats=[.17, .17, .17, .16, .17, .16]),
    "new": dict(share=.22, age=(30, 9, 18, 65), inc=(700_000, 300_000, 200_000, 2_000_000),
                n_orders=lambda: rng.poisson(2) + 1, rec_scale=25, aov=1800,
                disc=.35, online=.70, ret=.06, loyal=.10, tier=[.45, .35, .20],
                cats=[.18, .22, .14, .16, .12, .18]),
}
names = list(G)
shares = np.array([G[n]["share"] for n in names])
group_of = rng.choice(names, size=N_CUSTOMERS, p=shares / shares.sum())

customers, truth, txns = [], [], []
tid = 100000
for i, grp in enumerate(group_of):
    cid = f"C{i + 1:05d}"
    p = G[grp]
    a_mu, a_sd, a_lo, a_hi = p["age"]
    i_mu, i_sd, i_lo, i_hi = p["inc"]
    age = int(np.clip(rng.normal(a_mu, a_sd), a_lo, a_hi))
    income = int(round(np.clip(rng.normal(i_mu, i_sd), i_lo, i_hi), -3))

    # sign-up date and last purchase date depend on the group
    if grp == "new":
        age_days = int(rng.integers(10, 121))
        signup = SNAPSHOT - pd.Timedelta(days=age_days)
        recency = int(min(rng.exponential(p["rec_scale"]), age_days - 1))
    elif grp == "lapsed":
        signup = pd.Timestamp("2024-01-01") + pd.Timedelta(days=int(rng.integers(0, 121)))
        recency = int(rng.integers(190, 541))
    else:
        signup = pd.Timestamp("2024-01-01") + pd.Timedelta(days=int(rng.integers(0, 455)))
        recency = int(min(rng.exponential(p["rec_scale"]), (SNAPSHOT - signup).days - 30))
    last_date = SNAPSHOT - pd.Timedelta(days=max(recency, 0))
    if grp != "new" and last_date < signup + pd.Timedelta(days=30):
        last_date = signup + pd.Timedelta(days=30 + int(rng.integers(0, 60)))
    last_date = min(max(last_date, signup), SNAPSHOT)  # never before sign-up or after the snapshot

    n = max(1, int(p["n_orders"]()))
    span = max((last_date - signup).days, 1)
    offsets = np.sort(rng.integers(0, span + 1, size=n))
    offsets[-1] = span  # make sure the last order lands on last_date
    dates = [signup + pd.Timedelta(days=int(o)) for o in offsets]

    # Real customers do not fit neatly into one box: about 15% borrow the spending habits
    # (order value, discount use, channel, taste) of another group, which creates overlap.
    q = G[rng.choice([n for n in names if n != grp])] if rng.random() < .15 else p
    cat_p = rng.dirichlet(np.array(q["cats"]) * 30)       # each customer has own taste
    cust_aov = q["aov"] * rng.lognormal(0, 0.30)
    cust_disc = np.clip(q["disc"] + rng.normal(0, .10), 0, 1)
    cust_online = np.clip(q["online"] + rng.normal(0, .12), 0, 1)
    cust_ret = np.clip(q["ret"] + rng.normal(0, .03), 0, 1)

    for d in dates:
        tid += 1
        used_disc = rng.random() < cust_disc
        disc_pct = rng.choice([10, 15, 20, 30]) if used_disc else 0
        qty = 1 + rng.poisson(0.6 if grp in ("champions", "deal_seekers") else 0.3)
        amount = cust_aov * rng.lognormal(0, 0.35) * (1 - disc_pct / 100)
        txns.append((f"T{tid}", cid, d.date().isoformat(), rng.choice(CATS, p=cat_p),
                     round(float(amount), 2), int(qty), int(used_disc),
                     "Online" if rng.random() < cust_online else "Store",
                     int(rng.random() < cust_ret)))

    customers.append((cid, age, rng.choice(["Female", "Male", "Other"], p=[.49, .48, .03]),
                      income, rng.choice(["Tier 1", "Tier 2", "Tier 3"], p=p["tier"]),
                      rng.choice(["Organic", "Social Ads", "Referral", "Email", "Search"],
                                 p=[.25, .25, .15, .15, .20]),
                      int(rng.random() < p["loyal"]), signup.date().isoformat()))
    truth.append((cid, grp))

cust = pd.DataFrame(customers, columns=["customer_id", "age", "gender", "annual_income",
                                        "city_tier", "acquisition_channel", "loyalty_member", "signup_date"])
tx = pd.DataFrame(txns, columns=["transaction_id", "customer_id", "order_date", "product_category",
                                 "amount", "quantity", "discount_used", "channel", "returned"])

# Make the data a little messy, like real exports: missing values and duplicate rows
cust.loc[rng.choice(cust.index, int(.02 * len(cust)), replace=False), "annual_income"] = np.nan
cust.loc[rng.choice(cust.index, int(.01 * len(cust)), replace=False), "age"] = np.nan
dups = tx.sample(40, random_state=1)
tx = pd.concat([tx, dups], ignore_index=True).sample(frac=1, random_state=3).reset_index(drop=True)

cust.to_csv(RAW / "customers.csv", index=False)
tx.to_csv(RAW / "transactions.csv", index=False)
pd.DataFrame(truth, columns=["customer_id", "true_group"]).to_csv(RAW / "_ground_truth.csv", index=False)
print(f"customers.csv:    {len(cust):,} rows")
print(f"transactions.csv: {len(tx):,} rows (includes 40 duplicate rows to clean)")
