"""
Step 2: customer segmentation pipeline.

    cleaning -> features -> choose k -> cluster -> validate -> profile -> charts -> report

Run:   python scripts/02_segmentation.py            (k chosen automatically)
       python scripts/02_segmentation.py --k 4      (force a number of segments)

Outputs
    data/processed/customer_features.csv      one row per customer, all engineered features
    data/processed/customer_segments.csv      features + segment label (Power BI / Excel ready)
    outputs/segment_profiles.csv              one row per segment, averages and revenue share
    outputs/model_selection.csv               k = 2..10 scores
    outputs/algorithm_comparison.csv          KMeans vs hierarchical vs Gaussian mixture
    outputs/figures/*.png                     all charts
    reports/segmentation_report.md            written findings with the real numbers
"""
import argparse
import warnings
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.ticker import FuncFormatter, MaxNLocator
from scipy.optimize import linear_sum_assignment
from sklearn.cluster import AgglomerativeClustering, KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import (adjusted_rand_score, calinski_harabasz_score,
                             davies_bouldin_score, silhouette_samples, silhouette_score)
from sklearn.mixture import GaussianMixture
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore")
ROOT = Path(__file__).resolve().parent.parent
RAW, PROC, OUT = ROOT / "data" / "raw", ROOT / "data" / "processed", ROOT / "outputs"
FIG, REP = OUT / "figures", ROOT / "reports"
for d in (PROC, OUT, FIG, REP):
    d.mkdir(parents=True, exist_ok=True)

SEED = 42
SNAPSHOT = pd.Timestamp("2025-12-31")
CATS = ["Electronics", "Fashion", "Home & Kitchen", "Beauty", "Sports & Fitness", "Grocery"]

# Features used to build the clusters (behaviour + demographics)
CLUSTER_FEATURES = ["recency_days", "frequency", "monetary", "avg_order_value", "discount_share",
                    "online_share", "tenure_days", "age", "annual_income"]
LOG_FEATURES = ["recency_days", "frequency", "monetary", "avg_order_value", "annual_income"]
LABELS = {  # friendly names for charts
    "recency_days": "Days since last order", "frequency": "Orders", "monetary": "Total spend",
    "avg_order_value": "Avg order value", "discount_share": "Discount use", "online_share": "Online share",
    "tenure_days": "Days as customer", "age": "Age", "annual_income": "Annual income",
    "return_rate": "Return rate", "avg_items": "Items per order",
}
COLORS = {"Champions": "#0B7A75", "Premium Occasional": "#3B5BA9", "Deal Seekers": "#E0A100",
          "New Customers": "#7FA032", "At-Risk / Lapsed": "#C8553D"}
FALLBACK = ["#8E5BA8", "#2C9CD0", "#A8651F", "#6B7A86", "#C2528B"]

plt.rcParams.update({
    "figure.dpi": 110, "savefig.dpi": 150, "savefig.bbox": "tight", "font.size": 10.5,
    "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.alpha": .25,
    "axes.titleweight": "bold", "axes.titlesize": 12.5, "axes.titlelocation": "left",
})
inr = FuncFormatter(lambda v, _: f"₹{round(v/1e5, 1):g}L" if v >= 1e5 else f"₹{v/1e3:.0f}K" if v >= 1e3 else f"₹{v:.0f}")


def md_table(df, floatfmt="{:,.1f}"):
    """Tiny markdown-table writer (avoids needing the 'tabulate' package)."""
    cols = list(df.columns)
    rows = ["| " + " | ".join(str(c) for c in cols) + " |", "|" + "|".join("---" for _ in cols) + "|"]
    for _, r in df.iterrows():
        cells = [floatfmt.format(v) if isinstance(v, (float, np.floating)) else str(v) for v in r]
        rows.append("| " + " | ".join(cells) + " |")
    return "\n".join(rows)


# %% 1. Load and clean ---------------------------------------------------------
def load_and_clean():
    cust = pd.read_csv(RAW / "customers.csv", parse_dates=["signup_date"])
    tx = pd.read_csv(RAW / "transactions.csv", parse_dates=["order_date"])
    log = {"customers_raw": len(cust), "transactions_raw": len(tx)}

    dups = int(tx.duplicated().sum())
    tx = tx.drop_duplicates()
    log["duplicate_rows_removed"] = dups
    bad = int((tx["amount"] <= 0).sum())
    tx = tx[tx["amount"] > 0]
    log["non_positive_amounts_removed"] = bad
    log["missing_age"] = int(cust["age"].isna().sum())
    log["missing_income"] = int(cust["annual_income"].isna().sum())
    cust["age"] = cust["age"].fillna(cust["age"].median())
    cust["annual_income"] = cust["annual_income"].fillna(cust["annual_income"].median())
    log["customers_without_orders"] = int((~cust["customer_id"].isin(tx["customer_id"])).sum())
    log["transactions_clean"] = len(tx)
    return cust, tx, log


# %% 2. Feature engineering ----------------------------------------------------
def build_features(cust, tx):
    tx = tx.copy()
    tx["is_online"] = (tx["channel"] == "Online").astype(int)
    g = tx.groupby("customer_id")
    f = pd.DataFrame({
        "recency_days": (SNAPSHOT - g["order_date"].max()).dt.days,
        "frequency": g.size(),
        "monetary": g["amount"].sum(),
        "avg_order_value": g["amount"].mean(),
        "avg_items": g["quantity"].mean(),
        "discount_share": g["discount_used"].mean(),
        "online_share": g["is_online"].mean(),
        "return_rate": g["returned"].mean(),
    })
    spend = tx.pivot_table(index="customer_id", columns="product_category", values="amount",
                           aggfunc="sum", fill_value=0)
    spend = spend.reindex(columns=CATS, fill_value=0)
    share = spend.div(spend.sum(axis=1), axis=0).add_prefix("share_")
    df = cust.set_index("customer_id").join(f, how="inner").join(share)
    df["tenure_days"] = (SNAPSHOT - df["signup_date"]).dt.days
    df["top_category"] = spend.idxmax(axis=1)
    return df.reset_index(), tx


# %% 3. Model selection --------------------------------------------------------
def prepare_matrix(df):
    X = df[CLUSTER_FEATURES].copy()
    for c in LOG_FEATURES:
        X[c] = np.log1p(X[c])
    return StandardScaler().fit_transform(X)


def evaluate_k(X, ks=range(2, 11)):
    rows = []
    for k in ks:
        km = KMeans(n_clusters=k, n_init=20, random_state=SEED).fit(X)
        rows.append(dict(k=k, inertia=km.inertia_, silhouette=silhouette_score(X, km.labels_),
                         calinski_harabasz=calinski_harabasz_score(X, km.labels_),
                         davies_bouldin=davies_bouldin_score(X, km.labels_)))
    return pd.DataFrame(rows)


def choose_k(ms, lo=3, hi=8):
    """Highest silhouette among k = 3..8 (k=2 is too coarse to act on, k>8 too many to manage)."""
    sub = ms[(ms.k >= lo) & (ms.k <= hi)]
    return int(sub.loc[sub.silhouette.idxmax(), "k"])


def compare_algorithms(X, k, km_labels):
    out = []
    models = {
        "K-Means": km_labels,
        "Hierarchical (Ward)": AgglomerativeClustering(n_clusters=k, linkage="ward").fit_predict(X),
        "Gaussian mixture": GaussianMixture(n_components=k, covariance_type="full", n_init=5,
                                            random_state=SEED).fit(X).predict(X),
    }
    for name, lab in models.items():
        out.append(dict(algorithm=name, silhouette=silhouette_score(X, lab),
                        davies_bouldin=davies_bouldin_score(X, lab),
                        agreement_with_kmeans_ARI=adjusted_rand_score(km_labels, lab)))
    return pd.DataFrame(out)


def stability(X, k, ref_labels, n=30):
    """Refit on random 80% samples, predict everyone, compare with the main solution."""
    rng = np.random.default_rng(SEED)
    scores = []
    for i in range(n):
        idx = rng.choice(len(X), int(.8 * len(X)), replace=False)
        km = KMeans(n_clusters=k, n_init=10, random_state=i).fit(X[idx])
        scores.append(adjusted_rand_score(ref_labels, km.predict(X)))
    return float(np.mean(scores)), float(np.min(scores))


# %% 4. Naming and profiling ---------------------------------------------------
def name_segments(df, labels):
    """Name clusters by matching their profile to the business archetypes (one name per cluster)."""
    prof = df.assign(c=labels).groupby("c")[CLUSTER_FEATURES].mean()
    z = (prof - prof.mean()) / prof.std(ddof=0).replace(0, 1)
    scores = {
        "Champions": z.frequency + z.monetary - z.recency_days,
        "At-Risk / Lapsed": 2 * z.recency_days - z.tenure_days * 0,
        "New Customers": -2 * z.tenure_days - z.frequency,
        "Deal Seekers": z.discount_share + z.online_share - z.age - z.annual_income,
        "Premium Occasional": z.avg_order_value + z.annual_income + z.age - z.frequency,
    }
    names = list(scores)
    M = np.column_stack([scores[n].values for n in names])  # clusters x names
    r, c = linear_sum_assignment(-M)
    mapping = {prof.index[i]: names[j] for i, j in zip(r, c)}
    for i, cl in enumerate(prof.index):  # clusters left without a name (k > 5)
        mapping.setdefault(cl, f"Segment {cl + 1}")
    return mapping


def seg_colors(order):
    fb = iter(FALLBACK)
    return {s: COLORS.get(s) or next(fb) for s in order}


def build_profiles(df):
    tot_rev = df.monetary.sum()
    g = df.groupby("segment")
    p = pd.DataFrame({
        "customers": g.size(),
        "pct_customers": g.size() / len(df) * 100,
        "revenue": g.monetary.sum(),
        "pct_revenue": g.monetary.sum() / tot_rev * 100,
        "avg_recency_days": g.recency_days.mean(),
        "avg_orders": g.frequency.mean(),
        "avg_spend": g.monetary.mean(),
        "avg_order_value": g.avg_order_value.mean(),
        "discount_share_pct": g.discount_share.mean() * 100,
        "online_share_pct": g.online_share.mean() * 100,
        "return_rate_pct": g.return_rate.mean() * 100,
        "avg_age": g.age.mean(),
        "avg_income": g.annual_income.mean(),
        "avg_tenure_days": g.tenure_days.mean(),
        "loyalty_member_pct": g.loyalty_member.mean() * 100,
        "top_category": g.top_category.agg(lambda s: s.value_counts().index[0]),
    })
    return p.sort_values("revenue", ascending=False)


ACTIONS = {
    "Champions": ("Your best customers: frequent, recent, high spend.",
                  "Protect and reward: early access to launches, loyalty perks, referral programme. Avoid blanket discounts, they already buy at full price."),
    "Premium Occasional": ("Infrequent but very large baskets, older and higher income, prefer stores and big-ticket categories.",
                           "Raise purchase frequency with concierge service, extended warranties, accessories and timely replacement reminders. Lead with quality, not price."),
    "Deal Seekers": ("Young, price-sensitive, mostly online, heavy discount use and more returns.",
                     "Use targeted promotions and bundles to lift basket size, set free-shipping thresholds, and watch margin and returns closely."),
    "New Customers": ("Recently joined, only a few orders so far.",
                      "Run an onboarding journey: welcome offer, second-purchase incentive within 30 days, category recommendations. The goal is a fast second order."),
    "At-Risk / Lapsed": ("Used to buy regularly but have not ordered for a long time.",
                         "Win-back campaign: personal offer plus 'we miss you' messaging, then a survey on why they left. Stop spending on those who do not respond after two attempts."),
}


# %% 5. Charts -----------------------------------------------------------------
def fig_eda(df):
    fig, ax = plt.subplots(2, 3, figsize=(13, 7))
    spec = [("recency_days", "Days since last order", False), ("frequency", "Orders per customer", False),
            ("monetary", "Total spend", True), ("avg_order_value", "Average order value", True),
            ("age", "Age", False), ("annual_income", "Annual income", True)]
    for a, (c, t, money) in zip(ax.ravel(), spec):
        a.hist(df[c], bins=40, color="#0B7A75", alpha=.85)
        a.set_title(t); a.set_ylabel("Customers")
        if money:
            a.xaxis.set_major_formatter(inr)
    fig.suptitle("Raw customer features are skewed, so spend and frequency are log-transformed before clustering",
                 x=.01, ha="left", fontweight="bold", y=1.0)
    fig.tight_layout(); fig.savefig(FIG / "01_feature_distributions.png"); plt.close(fig)


def fig_corr(df):
    cols = CLUSTER_FEATURES + ["return_rate"]
    c = df[cols].corr()
    fig, ax = plt.subplots(figsize=(8.5, 7))
    im = ax.imshow(c, cmap="RdBu_r", vmin=-1, vmax=1)
    ax.set_xticks(range(len(cols))); ax.set_yticks(range(len(cols)))
    ax.set_xticklabels([LABELS[x] for x in cols], rotation=45, ha="right")
    ax.set_yticklabels([LABELS[x] for x in cols]); ax.grid(False)
    for i in range(len(cols)):
        for j in range(len(cols)):
            ax.text(j, i, f"{c.iloc[i, j]:.2f}", ha="center", va="center", fontsize=8,
                    color="white" if abs(c.iloc[i, j]) > .55 else "#222")
    ax.set_title("How the features move together"); fig.colorbar(im, shrink=.8)
    fig.savefig(FIG / "02_correlation_heatmap.png"); plt.close(fig)


def fig_k(ms, k):
    fig, ax = plt.subplots(1, 4, figsize=(15, 3.6))
    spec = [("inertia", "Elbow (inertia, lower is tighter)"), ("silhouette", "Silhouette (higher is better)"),
            ("calinski_harabasz", "Calinski-Harabasz (higher is better)"), ("davies_bouldin", "Davies-Bouldin (lower is better)")]
    for a, (c, t) in zip(ax, spec):
        a.plot(ms.k, ms[c], marker="o", color="#3B5BA9", lw=2)
        a.axvline(k, color="#C8553D", ls="--", lw=1.5); a.set_title(t, fontsize=10.5); a.set_xlabel("Number of segments (k)")
    ax[1].annotate(f"chosen k = {k}", (k, ms.loc[ms.k == k, "silhouette"].iloc[0]), xytext=(8, -22),
                   textcoords="offset points", color="#C8553D", fontweight="bold")
    fig.tight_layout(); fig.savefig(FIG / "03_choosing_k.png"); plt.close(fig)


def fig_pca(df, X, order, colors, pca):
    Z = pca.transform(X)
    fig, ax = plt.subplots(figsize=(8.5, 6.5))
    for s in order:
        m = (df.segment == s).values
        ax.scatter(Z[m, 0], Z[m, 1], s=9, alpha=.55, color=colors[s], label=f"{s} ({m.sum():,})")
        ax.annotate(s, Z[m].mean(axis=0), fontsize=10, fontweight="bold", ha="center",
                    bbox=dict(boxstyle="round,pad=.25", fc="white", ec=colors[s], alpha=.9))
    ev = pca.explained_variance_ratio_ * 100
    ax.set_xlabel(f"Component 1 ({ev[0]:.0f}% of variation)"); ax.set_ylabel(f"Component 2 ({ev[1]:.0f}% of variation)")
    ax.set_title("Customer segments projected to two dimensions (PCA)")
    ax.legend(markerscale=2.5, frameon=False, loc="best", fontsize=9)
    fig.savefig(FIG / "04_segments_pca.png"); plt.close(fig)


def fig_size_revenue(prof, colors):
    p = prof.sort_values("pct_revenue", ascending=True)
    y = np.arange(len(p)); h = .38
    fig, ax = plt.subplots(figsize=(9, 4.6))
    ax.barh(y + h / 2, p.pct_customers, h, color="#B8C4CC", label="% of customers")
    ax.barh(y - h / 2, p.pct_revenue, h, color=[colors[s] for s in p.index], label="% of revenue")
    for i, (a, b) in enumerate(zip(p.pct_customers, p.pct_revenue)):
        ax.text(a + .4, i + h / 2, f"{a:.0f}%", va="center", fontsize=9)
        ax.text(b + .4, i - h / 2, f"{b:.0f}%", va="center", fontsize=9, fontweight="bold")
    ax.set_yticks(y); ax.set_yticklabels(p.index); ax.grid(axis="y", visible=False)
    ax.set_xlabel("Share of total"); ax.set_title("Who the customers are versus where the revenue comes from")
    ax.legend(frameon=False, loc="lower right"); fig.savefig(FIG / "05_customers_vs_revenue.png"); plt.close(fig)


def fig_profile_heatmap(df, order):
    cols = ["recency_days", "frequency", "monetary", "avg_order_value", "discount_share", "online_share",
            "return_rate", "tenure_days", "age", "annual_income"]
    idx = (df.groupby("segment")[cols].mean() / df[cols].mean() * 100).loc[order]
    fig, ax = plt.subplots(figsize=(11, 4.6))
    im = ax.imshow(idx.values, cmap="PuOr_r", vmin=0, vmax=200, aspect="auto")
    ax.set_xticks(range(len(cols))); ax.set_xticklabels([LABELS[c] for c in cols], rotation=35, ha="right")
    ax.set_yticks(range(len(order))); ax.set_yticklabels(order); ax.grid(False)
    for i in range(idx.shape[0]):
        for j in range(idx.shape[1]):
            v = idx.iloc[i, j]; ax.text(j, i, f"{v:.0f}", ha="center", va="center", fontsize=9,
                                        color="white" if v > 150 or v < 45 else "#222")
    ax.set_title("Segment profile index (100 = average customer; 150 means 50% above average)")
    fig.colorbar(im, shrink=.85); fig.savefig(FIG / "06_segment_profile_heatmap.png"); plt.close(fig)


def fig_categories(df, tx, order):
    t = tx.merge(df[["customer_id", "segment"]], on="customer_id")
    pv = t.pivot_table(index="segment", columns="product_category", values="amount", aggfunc="sum").reindex(order)[CATS]
    sh = pv.div(pv.sum(axis=1), axis=0) * 100
    fig, ax = plt.subplots(figsize=(9.5, 4.6))
    im = ax.imshow(sh.values, cmap="GnBu", aspect="auto")
    ax.set_xticks(range(len(CATS))); ax.set_xticklabels(CATS, rotation=25, ha="right")
    ax.set_yticks(range(len(order))); ax.set_yticklabels(order); ax.grid(False)
    for i in range(sh.shape[0]):
        for j in range(sh.shape[1]):
            v = sh.iloc[i, j]; ax.text(j, i, f"{v:.0f}%", ha="center", va="center", fontsize=9.5,
                                       color="white" if v > sh.values.max() * .62 else "#222")
    ax.set_title("What each segment spends on (share of the segment's own spend)")
    fig.colorbar(im, shrink=.85, label="% of segment spend"); fig.savefig(FIG / "07_category_preferences.png"); plt.close(fig)
    return sh


def fig_demographics(df, order, colors):
    fig, ax = plt.subplots(1, 3, figsize=(14, 4.4))
    for a, c, t, fmt in [(ax[0], "age", "Age", None), (ax[1], "annual_income", "Annual income", inr)]:
        data = [df.loc[df.segment == s, c] for s in order]
        bp = a.boxplot(data, vert=False, patch_artist=True, widths=.6, showfliers=False,
                       medianprops=dict(color="#111", lw=1.6))
        for patch, s in zip(bp["boxes"], order):
            patch.set_facecolor(colors[s]); patch.set_alpha(.8)
        a.set_yticklabels(order if a is ax[0] else [""] * len(order)); a.set_title(t); a.grid(axis="y", visible=False)
        if fmt:
            a.xaxis.set_major_formatter(fmt); a.xaxis.set_major_locator(MaxNLocator(5))
    ct = pd.crosstab(df.segment, df.city_tier, normalize="index").reindex(order) * 100
    left = np.zeros(len(order))
    for tier, col in zip(ct.columns, ["#0B7A75", "#7DB8B4", "#D4E6E4"]):
        ax[2].barh(range(len(order)), ct[tier], left=left, color=col, label=tier); left += ct[tier].values
    ax[2].set_yticks(range(len(order))); ax[2].set_yticklabels([""] * len(order)); ax[2].invert_yaxis()
    ax[2].set_title("City tier mix (%)"); ax[2].legend(frameon=False, fontsize=8, ncol=3, loc="lower center",
                                                      bbox_to_anchor=(.5, -.22)); ax[2].grid(False)
    ax[0].invert_yaxis(); ax[1].invert_yaxis()
    fig.savefig(FIG / "08_demographics_by_segment.png"); plt.close(fig)


def fig_time(df, tx, order, colors):
    t = tx.merge(df[["customer_id", "segment"]], on="customer_id")
    t["month"] = t.order_date.dt.to_period("M").dt.to_timestamp()
    pv = t.pivot_table(index="month", columns="segment", values="amount", aggfunc="sum", fill_value=0)[order]
    fig, ax = plt.subplots(figsize=(11, 4.6))
    ax.stackplot(pv.index, pv.T.values, labels=order, colors=[colors[s] for s in order], alpha=.9)
    ax.yaxis.set_major_formatter(inr); ax.set_title("Monthly revenue by segment")
    ax.legend(frameon=False, loc="upper left", ncol=3, fontsize=9); fig.savefig(FIG / "09_revenue_over_time.png"); plt.close(fig)


def fig_silhouette(X, labels, df, order, colors):
    s = silhouette_samples(X, labels)
    fig, ax = plt.subplots(figsize=(8, 5.2)); y0 = 5
    for seg in order:
        v = np.sort(s[(df.segment == seg).values]); ax.fill_betweenx(np.arange(y0, y0 + len(v)), 0, v,
                                                                      color=colors[seg], alpha=.85)
        ax.text(-.27, y0 + len(v) / 2, seg, va="center", fontsize=9); y0 += len(v) + 40
    ax.axvline(s.mean(), color="#C8553D", ls="--"); ax.set_yticks([]); ax.set_xlim(-.3, 1)
    ax.set_xlabel("Silhouette value"); ax.set_title(f"How well each customer fits their segment (average {s.mean():.2f})")
    ax.grid(axis="y", visible=False); fig.savefig(FIG / "10_silhouette_by_segment.png"); plt.close(fig)


# %% 6. Report -----------------------------------------------------------------
def write_report(log, df, prof, ms, k, algo, stab, ari_truth, order, sh_cat, pca_ev):
    def money(v): return f"₹{v/1e7:.2f} Cr" if v >= 1e7 else f"₹{v/1e5:.1f} L" if v >= 1e5 else f"₹{v:,.0f}"
    tot = df.monetary.sum(); best = ms.loc[ms.k == k].iloc[0]
    top = prof.index[0]; top_share = prof.loc[top, "pct_revenue"]
    champ = prof.loc["Champions"] if "Champions" in prof.index else None
    lapsed = prof.loc["At-Risk / Lapsed"] if "At-Risk / Lapsed" in prof.index else None
    L = []
    L.append("# Customer Segmentation Report\n")
    L.append(f"**Snapshot date:** {SNAPSHOT.date()}  |  **Customers analysed:** {len(df):,}  |  "
             f"**Orders:** {log['transactions_clean']:,}  |  **Total revenue:** {money(tot)}  |  **Segments found:** {k}\n")
    L.append("> The data in this project is simulated (real customer data is private), so the findings describe the "
             "simulated shop, not a real business. The method is the same one you would apply to real data.\n")

    L.append("## 1. Summary\n")
    L.append(f"The analysis groups {len(df):,} customers into **{k} segments** using what they buy, how often, how recently, "
             "how they pay and who they are.\n")
    pts = []
    if champ is not None:
        pts.append(f"**Champions are {champ.pct_customers:.0f}% of customers but {champ.pct_revenue:.0f}% of revenue.** "
                   f"They order about {champ.avg_orders:.0f} times and spend {money(champ.avg_spend)} each on average. Losing them would hurt most.")
    if lapsed is not None:
        pts.append(f"**At-Risk / Lapsed customers are {lapsed.pct_customers:.0f}% of the base** and have not ordered for "
                   f"{lapsed.avg_recency_days:.0f} days on average. They once ordered {lapsed.avg_orders:.0f} times, so they are worth a win-back attempt.")
    if "Deal Seekers" in prof.index:
        d = prof.loc["Deal Seekers"]
        pts.append(f"**Deal Seekers are the biggest group by headcount ({d.pct_customers:.0f}%)** but contribute only {d.pct_revenue:.0f}% of revenue, "
                   f"with {d.discount_share_pct:.0f}% of their orders using a discount and a {d.return_rate_pct:.0f}% return rate.")
    if "Premium Occasional" in prof.index:
        d = prof.loc["Premium Occasional"]
        pts.append(f"**Premium Occasional customers** place only {d.avg_orders:.1f} orders but each is worth {money(d.avg_order_value)}, "
                   f"so {d.pct_customers:.0f}% of customers generate {d.pct_revenue:.0f}% of revenue.")
    pts.append(f"The top segment by revenue is **{top}** ({top_share:.0f}% of revenue).")
    L.extend(f"- {p}" for p in pts); L.append("")

    L.append("## 2. Data and cleaning\n")
    L.append(md_table(pd.DataFrame([
        ["Customers loaded", f"{log['customers_raw']:,}"], ["Transactions loaded", f"{log['transactions_raw']:,}"],
        ["Duplicate transactions removed", f"{log['duplicate_rows_removed']:,}"],
        ["Non-positive amounts removed", f"{log['non_positive_amounts_removed']:,}"],
        ["Missing age filled with median", f"{log['missing_age']:,}"],
        ["Missing income filled with median", f"{log['missing_income']:,}"],
        ["Customers with no orders (excluded)", f"{log['customers_without_orders']:,}"],
        ["Transactions used", f"{log['transactions_clean']:,}"]], columns=["Step", "Count"])) + "\n")

    L.append("## 3. Method\n")
    L.append("1. **Features per customer.** Recency (days since last order), frequency (orders), monetary (total spend), "
             "average order value, share of orders using a discount, share of orders placed online, tenure, age and income. "
             "Product-category preferences, return rate and loyalty membership were deliberately **left out of the clustering** and used "
             "afterwards to describe the segments, which gives an independent check that the segments mean something.")
    L.append("2. **Transform and scale.** Spend, frequency, order value, recency and income are right-skewed, so they were log-transformed, "
             "then all features were standardised so no single unit dominates the distance calculation.")
    L.append(f"3. **Choosing the number of segments.** K-Means was run for k = 2 to 10 and judged on four measures (figure below). "
             f"Among k = 3 to 8, **k = {k}** had the best silhouette score ({best.silhouette:.2f}), the Davies-Bouldin index was {best.davies_bouldin:.2f}, "
             "and the result is small enough to act on.")
    L.append("4. **Comparing algorithms.** K-Means was compared with hierarchical (Ward) and Gaussian-mixture clustering at the same k.")
    L.append("5. **Stability check.** K-Means was refitted on 30 random 80% samples to see whether the same groups come back.\n")
    L.append("![Choosing k](../outputs/figures/03_choosing_k.png)\n")
    L.append(md_table(algo.round(3), "{:.3f}") + "\n")
    L.append(f"**Stability:** average agreement with the final solution was **{stab[0]:.2f}** (adjusted Rand index, 1.0 = identical), "
             f"worst case {stab[1]:.2f}. ")
    if ari_truth is not None:
        L.append(f"**Validation against the hidden truth:** because the data is simulated we know the true groups. "
                 f"The segments recover them with an adjusted Rand index of **{ari_truth:.2f}**. On real data no such answer key exists, "
                 "so rely on silhouette, stability and business sense instead.\n")
    L.append("![Silhouette by segment](../outputs/figures/10_silhouette_by_segment.png)\n")

    L.append("## 4. The segments\n")
    L.append("![Segments in 2D](../outputs/figures/04_segments_pca.png)\n")
    L.append(f"*The first two principal components capture {pca_ev:.0f}% of the variation, so some overlap in this 2D view is expected.*\n")
    show = prof.reset_index()[["segment", "customers", "pct_customers", "pct_revenue", "avg_recency_days", "avg_orders",
                               "avg_spend", "avg_order_value", "discount_share_pct", "online_share_pct", "avg_age", "avg_income"]].copy()
    show.columns = ["Segment", "Customers", "% cust.", "% revenue", "Days since order", "Orders", "Avg spend", "Avg order",
                    "Discount %", "Online %", "Age", "Income"]
    for c in ["Avg spend", "Avg order", "Income"]:
        show[c] = show[c].map(lambda v: f"₹{v:,.0f}")
    show["Customers"] = show["Customers"].map("{:,}".format)
    L.append(md_table(show, "{:.0f}") + "\n")
    L.append("![Customers vs revenue](../outputs/figures/05_customers_vs_revenue.png)\n")
    L.append("![Profile heatmap](../outputs/figures/06_segment_profile_heatmap.png)\n")

    L.append("## 5. Purchase patterns and preferences\n")
    L.append("![Category preferences](../outputs/figures/07_category_preferences.png)\n")
    bullets = []
    for s in order:
        row = sh_cat.loc[s].sort_values(ascending=False)
        bullets.append(f"- The **{s}** segment spends most on {row.index[0]} ({row.iloc[0]:.0f}% of its spend) and {row.index[1]} ({row.iloc[1]:.0f}%).")
    L.extend(bullets); L.append("")
    L.append("![Demographics](../outputs/figures/08_demographics_by_segment.png)\n")
    L.append("![Revenue over time](../outputs/figures/09_revenue_over_time.png)\n")
    L.append("*Reading the chart: revenue climbs through 2024 mainly because customers joined over the year, not because each customer spent more. "
             "The At-Risk / Lapsed band shrinks as those customers stop ordering, and the New Customers band appears only at the end because they joined recently.*\n")

    L.append("## 6. Who they are and what to do\n")
    for s in order:
        p = prof.loc[s]; who, act = ACTIONS.get(s, ("A smaller group with a mixed profile.", "Review its profile before targeting."))
        L.append(f"### {s}\n")
        L.append(f"{who}\n")
        L.append(f"- Size: {int(p.customers):,} customers ({p.pct_customers:.0f}%), {money(p.revenue)} revenue ({p.pct_revenue:.0f}%)")
        L.append(f"- Last order {p.avg_recency_days:.0f} days ago, {p.avg_orders:.1f} orders, average order {money(p.avg_order_value)}")
        L.append(f"- Age {p.avg_age:.0f}, income {money(p.avg_income)}, {p.online_share_pct:.0f}% of orders online, {p.loyalty_member_pct:.0f}% loyalty members")
        L.append(f"- **Recommended action:** {act}\n")

    L.append("## 7. Limitations and next steps\n")
    L.append("- **Simulated data.** Real data is noisier, and segments overlap more.")
    L.append("- **K-Means assumes round, similar-sized groups.** The comparison table shows how other algorithms behave; check it on real data.")
    L.append("- **Snapshot, not a trend.** Customers move between segments over time. Re-run monthly and track migration (for example New to Champions, or Champions to At-Risk).")
    L.append("- **Segments describe, they do not prove cause.** Test any campaign with a control group before scaling it.")
    L.append("- **Next steps:** add margin data to rank segments by profit rather than revenue, add a churn model for early warning, and build a Power BI report on `data/processed/customer_segments.csv`.\n")
    (REP / "segmentation_report.md").write_text("\n".join(L), encoding="utf-8")


# %% Main ----------------------------------------------------------------------
def main(force_k=None):
    cust, tx, log = load_and_clean()
    df, tx = build_features(cust, tx)
    df.to_csv(PROC / "customer_features.csv", index=False)
    print(f"[1/6] cleaned: {len(df):,} customers, {len(tx):,} orders  {log}")

    X = prepare_matrix(df)
    ms = evaluate_k(X); ms.to_csv(OUT / "model_selection.csv", index=False)
    k = force_k or choose_k(ms)
    print(f"[2/6] model selection\n{ms.round(3).to_string(index=False)}\n      -> k = {k}")

    km = KMeans(n_clusters=k, n_init=50, random_state=SEED).fit(X)
    mapping = name_segments(df, km.labels_)
    df["cluster"] = km.labels_
    df["segment"] = df["cluster"].map(mapping)
    algo = compare_algorithms(X, k, km.labels_); algo.to_csv(OUT / "algorithm_comparison.csv", index=False)
    stab = stability(X, k, km.labels_)
    print(f"[3/6] algorithms\n{algo.round(3).to_string(index=False)}\n      stability ARI mean={stab[0]:.3f} min={stab[1]:.3f}")

    ari = None  # only available for the simulated data set
    if (RAW / "_ground_truth.csv").exists():
        truth = pd.read_csv(RAW / "_ground_truth.csv")
        ari = adjusted_rand_score(df.merge(truth, on="customer_id")["true_group"], df["segment"])
        print(f"      adjusted Rand vs hidden truth (simulated data only): {ari:.3f}")

    prof = build_profiles(df); prof.round(2).to_csv(OUT / "segment_profiles.csv")
    order = list(prof.index); colors = seg_colors(order)
    print(f"[4/6] profiles\n{prof.round(1).T.to_string()}")
    out = df.drop(columns=["cluster"]).copy()
    out["segment"] = df["segment"]
    out.to_csv(PROC / "customer_segments.csv", index=False)

    pca = PCA(n_components=2, random_state=SEED).fit(X)
    fig_eda(df); fig_corr(df); fig_k(ms, k); fig_pca(df, X, order, colors, pca); fig_size_revenue(prof, colors)
    fig_profile_heatmap(df, order); sh = fig_categories(df, tx, order); fig_demographics(df, order, colors)
    fig_time(df, tx, order, colors); fig_silhouette(X, km.labels_, df, order, colors)
    print(f"[5/6] saved {len(list(FIG.glob('*.png')))} figures")

    write_report(log, df, prof, ms, k, algo, stab, ari, order, sh, pca.explained_variance_ratio_[:2].sum() * 100)
    print("[6/6] report written -> reports/segmentation_report.md")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--k", type=int, default=None, help="force the number of segments")
    main(ap.parse_args().k)
