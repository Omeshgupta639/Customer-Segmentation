# Customer Segmentation Report

**Snapshot date:** 2025-12-31  |  **Customers analysed:** 3,000  |  **Orders:** 38,763  |  **Total revenue:** ₹11.64 Cr  |  **Segments found:** 5

> The data in this project is simulated (real customer data is private), so the findings describe the simulated shop, not a real business. The method is the same one you would apply to real data.

## 1. Summary

The analysis groups 3,000 customers into **5 segments** using what they buy, how often, how recently, how they pay and who they are.

- **Champions are 18% of customers but 52% of revenue.** They order about 28 times and spend ₹1.1 L each on average. Losing them would hurt most.
- **At-Risk / Lapsed customers are 22% of the base** and have not ordered for 350 days on average. They once ordered 11 times, so they are worth a win-back attempt.
- **Deal Seekers are the biggest group by headcount (25%)** but contribute only 10% of revenue, with 63% of their orders using a discount and a 12% return rate.
- **Premium Occasional customers** place only 6.1 orders but each is worth ₹9,761, so 14% of customers generate 21% of revenue.
- The top segment by revenue is **Champions** (52% of revenue).

## 2. Data and cleaning

| Step | Count |
|---|---|
| Customers loaded | 3,000 |
| Transactions loaded | 38,803 |
| Duplicate transactions removed | 40 |
| Non-positive amounts removed | 0 |
| Missing age filled with median | 30 |
| Missing income filled with median | 60 |
| Customers with no orders (excluded) | 0 |
| Transactions used | 38,763 |

## 3. Method

1. **Features per customer.** Recency (days since last order), frequency (orders), monetary (total spend), average order value, share of orders using a discount, share of orders placed online, tenure, age and income. Product-category preferences, return rate and loyalty membership were deliberately **left out of the clustering** and used afterwards to describe the segments, which gives an independent check that the segments mean something.
2. **Transform and scale.** Spend, frequency, order value, recency and income are right-skewed, so they were log-transformed, then all features were standardised so no single unit dominates the distance calculation.
3. **Choosing the number of segments.** K-Means was run for k = 2 to 10 and judged on four measures (figure below). Among k = 3 to 8, **k = 5** had the best silhouette score (0.35), the Davies-Bouldin index was 1.11, and the result is small enough to act on.
4. **Comparing algorithms.** K-Means was compared with hierarchical (Ward) and Gaussian-mixture clustering at the same k.
5. **Stability check.** K-Means was refitted on 30 random 80% samples to see whether the same groups come back.

![Choosing k](../outputs/figures/03_choosing_k.png)

| algorithm | silhouette | davies_bouldin | agreement_with_kmeans_ARI |
|---|---|---|---|
| K-Means | 0.352 | 1.111 | 1.000 |
| Hierarchical (Ward) | 0.343 | 1.094 | 0.921 |
| Gaussian mixture | 0.336 | 1.183 | 0.899 |

**Stability:** average agreement with the final solution was **1.00** (adjusted Rand index, 1.0 = identical), worst case 0.99. 
**Validation against the hidden truth:** because the data is simulated we know the true groups. The segments recover them with an adjusted Rand index of **0.88**. On real data no such answer key exists, so rely on silhouette, stability and business sense instead.

![Silhouette by segment](../outputs/figures/10_silhouette_by_segment.png)

## 4. The segments

![Segments in 2D](../outputs/figures/04_segments_pca.png)

*The first two principal components capture 61% of the variation, so some overlap in this 2D view is expected.*

| Segment | Customers | % cust. | % revenue | Days since order | Orders | Avg spend | Avg order | Discount % | Online % | Age | Income |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Champions | 525 | 18 | 52 | 12 | 28 | ₹114,479 | ₹4,234 | 15 | 56 | 37 | ₹1,270,545 |
| Premium Occasional | 417 | 14 | 21 | 70 | 6 | ₹59,176 | ₹9,761 | 10 | 29 | 49 | ₹1,894,341 |
| At-Risk / Lapsed | 654 | 22 | 14 | 350 | 11 | ₹24,353 | ₹2,273 | 30 | 51 | 43 | ₹800,471 |
| Deal Seekers | 738 | 25 | 10 | 29 | 17 | ₹15,824 | ₹925 | 63 | 83 | 24 | ₹382,171 |
| New Customers | 666 | 22 | 3 | 22 | 3 | ₹6,048 | ₹2,023 | 36 | 73 | 31 | ₹729,911 |

![Customers vs revenue](../outputs/figures/05_customers_vs_revenue.png)

![Profile heatmap](../outputs/figures/06_segment_profile_heatmap.png)

## 5. Purchase patterns and preferences

![Category preferences](../outputs/figures/07_category_preferences.png)

- The **Champions** segment spends most on Electronics (28% of its spend) and Home & Kitchen (21%).
- The **Premium Occasional** segment spends most on Electronics (42% of its spend) and Home & Kitchen (28%).
- The **At-Risk / Lapsed** segment spends most on Electronics (19% of its spend) and Home & Kitchen (18%).
- The **Deal Seekers** segment spends most on Fashion (29% of its spend) and Beauty (21%).
- The **New Customers** segment spends most on Fashion (20% of its spend) and Electronics (19%).

![Demographics](../outputs/figures/08_demographics_by_segment.png)

![Revenue over time](../outputs/figures/09_revenue_over_time.png)

*Reading the chart: revenue climbs through 2024 mainly because customers joined over the year, not because each customer spent more. The At-Risk / Lapsed band shrinks as those customers stop ordering, and the New Customers band appears only at the end because they joined recently.*

## 6. Who they are and what to do

### Champions

Your best customers: frequent, recent, high spend.

- Size: 525 customers (18%), ₹6.01 Cr revenue (52%)
- Last order 12 days ago, 27.9 orders, average order ₹4,234
- Age 37, income ₹12.7 L, 56% of orders online, 72% loyalty members
- **Recommended action:** Protect and reward: early access to launches, loyalty perks, referral programme. Avoid blanket discounts, they already buy at full price.

### Premium Occasional

Infrequent but very large baskets, older and higher income, prefer stores and big-ticket categories.

- Size: 417 customers (14%), ₹2.47 Cr revenue (21%)
- Last order 70 days ago, 6.1 orders, average order ₹9,761
- Age 49, income ₹18.9 L, 29% of orders online, 41% loyalty members
- **Recommended action:** Raise purchase frequency with concierge service, extended warranties, accessories and timely replacement reminders. Lead with quality, not price.

### At-Risk / Lapsed

Used to buy regularly but have not ordered for a long time.

- Size: 654 customers (22%), ₹1.59 Cr revenue (14%)
- Last order 350 days ago, 10.7 orders, average order ₹2,273
- Age 43, income ₹8.0 L, 51% of orders online, 37% loyalty members
- **Recommended action:** Win-back campaign: personal offer plus 'we miss you' messaging, then a survey on why they left. Stop spending on those who do not respond after two attempts.

### Deal Seekers

Young, price-sensitive, mostly online, heavy discount use and more returns.

- Size: 738 customers (25%), ₹1.17 Cr revenue (10%)
- Last order 29 days ago, 17.1 orders, average order ₹925
- Age 24, income ₹3.8 L, 83% of orders online, 29% loyalty members
- **Recommended action:** Use targeted promotions and bundles to lift basket size, set free-shipping thresholds, and watch margin and returns closely.

### New Customers

Recently joined, only a few orders so far.

- Size: 666 customers (22%), ₹40.3 L revenue (3%)
- Last order 22 days ago, 3.0 orders, average order ₹2,023
- Age 31, income ₹7.3 L, 73% of orders online, 11% loyalty members
- **Recommended action:** Run an onboarding journey: welcome offer, second-purchase incentive within 30 days, category recommendations. The goal is a fast second order.

## 7. Limitations and next steps

- **Simulated data.** Real data is noisier, and segments overlap more.
- **K-Means assumes round, similar-sized groups.** The comparison table shows how other algorithms behave; check it on real data.
- **Snapshot, not a trend.** Customers move between segments over time. Re-run monthly and track migration (for example New to Champions, or Champions to At-Risk).
- **Segments describe, they do not prove cause.** Test any campaign with a control group before scaling it.
- **Next steps:** add margin data to rank segments by profit rather than revenue, add a churn model for early warning, and build a Power BI report on `data/processed/customer_segments.csv`.
