# Customer Segmentation Project

Segment customers by **behaviour** (what, how often, how recently, how they pay) and **demographics** (age, income, city tier) using Python and scikit-learn, then turn the segments into targeted marketing actions.

**Full written findings:** [`reports/segmentation_report.md`](reports/segmentation_report.md)

![Customer segments](outputs/figures/04_segments_pca.png)

## What this project covers

| Task | Where |
|---|---|
| Clustering with Python (scikit-learn) | `scripts/02_segmentation.py` (K-Means, compared with hierarchical and Gaussian-mixture) |
| Clustering with Power BI | `docs/powerbi_guide.md` (build the interactive view on `data/processed/customer_segments.csv`) |
| Analyse purchase patterns and preferences | RFM features, category spend by segment, discount and channel behaviour, revenue over time |
| Visualize segments and key characteristics | 10 charts in `outputs/figures/` |
| Targeted insights | A recommended action per segment in the report |

## Results at a glance

| Segment | % customers | % revenue | Days since last order | Orders | Avg order value | Discount use | Typical customer |
|---|---|---|---|---|---|---|---|
| Champions | 18% | 52% | 12 | 28 | ₹4,234 | 15% | Age 37, high income, frequent, loyal |
| Premium Occasional | 14% | 21% | 70 | 6 | ₹9,761 | 10% | Age 49, highest income, big-ticket, in-store |
| At-Risk / Lapsed | 22% | 14% | 350 | 11 | ₹2,273 | 30% | Used to buy, silent for almost a year |
| Deal Seekers | 25% | 10% | 29 | 17 | ₹925 | 63% | Age 24, low income, online, discount-driven |
| New Customers | 22% | 3% | 22 | 3 | ₹2,023 | 36% | Joined in the last ~2 months |

Main takeaways:
- **18% of customers produce 52% of revenue.** Protecting Champions is the top priority.
- **Deal Seekers are the largest group but only 10% of revenue**, so discounting them heavily is a margin risk.
- **Nearly 1 in 4 customers is lapsed.** A win-back campaign has a clearly defined audience.
- Category preferences, which were *not* used to build the clusters, still differ strongly by segment (for example Premium Occasional spends 42% on Electronics, Deal Seekers 29% on Fashion). That is independent evidence the segments are meaningful.

Model quality: 5 segments chosen by silhouette score (0.35) among k = 3 to 8; three algorithms agree closely (adjusted Rand 0.90 to 0.92 against K-Means); refitting on random 80% samples reproduces the same groups (agreement 1.00).

## Quick start

```bash
git clone https://github.com/<your-username>/<repo-name>.git
cd <repo-name>
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
bash scripts/run_all.sh            # or run the two scripts below one by one
```

```bash
python scripts/01_generate_data.py        # creates data/raw/*.csv
python scripts/02_segmentation.py         # runs everything below, writes outputs and report
python scripts/02_segmentation.py --k 4   # optional: force a different number of segments
```

The results are reproducible (fixed random seeds). The pipeline takes under a minute.

## Pipeline

```
data/raw/customers.csv + transactions.csv
        │  clean: drop duplicate orders, fill missing age and income with the median
        ▼
customer features (one row per customer)
        │  recency, frequency, monetary, avg order value, discount share, online share,
        │  tenure, age, income   →   log-transform skewed columns, standardise
        ▼
choose k      K-Means for k = 2..10: elbow, silhouette, Calinski-Harabasz, Davies-Bouldin
        ▼
cluster       K-Means (n_init = 50), compared with hierarchical and Gaussian mixture
        ▼
validate      silhouette per customer, stability on 30 resamples
        ▼
profile       averages, revenue share, category mix, demographics, naming, actions
        ▼
outputs/ + reports/segmentation_report.md + data/processed/customer_segments.csv
```

### Why these choices
- **RFM plus behaviour plus demographics.** The task asks for both behaviour and demographics, so both feed the model. Category preference, returns and loyalty membership are held back to *describe* segments afterwards.
- **Log transform.** Spend and frequency are heavily right-skewed, and K-Means is distance-based, so a few big spenders would otherwise dominate.
- **k = 5.** It had the best silhouette between 3 and 8 and is a number a marketing team can run separate campaigns for.
- **Names come from the data.** Each cluster is matched to the archetype it resembles most (an optimal one-to-one assignment), so labels are reproducible and not typed in by hand.

## About the data

The data is **simulated** because real customer data is private. 3,000 customers and about 38,800 orders (2024 to 2025) are generated from five hidden behaviour groups, with about 15% of customers borrowing another group's habits so the groups overlap like real life, plus deliberate mess (missing values, 40 duplicate orders). `data/raw/_ground_truth.csv` holds the hidden group and is used for a single validation check (adjusted Rand index 0.88); it is never given to the model. On real data you will not have it.

**Using your own data:** replace `customers.csv` and `transactions.csv` in `data/raw/` with files that have the same columns (see below), delete `_ground_truth.csv` (the validation against it is then skipped automatically), and rerun `02_segmentation.py`. Update `SNAPSHOT` at the top of the script to your reporting date. The segment names are matched to behaviour, so with different data check that the names still fit.

| `customers.csv` | `transactions.csv` |
|---|---|
| customer_id, age, gender, annual_income, city_tier, acquisition_channel, loyalty_member, signup_date | transaction_id, customer_id, order_date, product_category, amount, quantity, discount_used (0/1), channel (Online/Store), returned (0/1) |

## Repository layout

```
customer-segmentation/
├── README.md
├── requirements.txt
├── LICENSE
├── data/
│   ├── raw/                    customers.csv, transactions.csv, _ground_truth.csv
│   └── processed/              customer_features.csv, customer_segments.csv (Power BI ready)
├── scripts/
│   ├── 01_generate_data.py
│   ├── 02_segmentation.py
│   └── run_all.sh
├── outputs/
│   ├── figures/                10 PNG charts
│   ├── segment_profiles.csv
│   ├── model_selection.csv
│   └── algorithm_comparison.csv
├── reports/segmentation_report.md
└── docs/powerbi_guide.md
```

## Limitations

- Simulated data, so the numbers describe a made-up shop.
- Revenue is used as the value measure; with margin data, rank segments by profit instead.
- Segments are a snapshot. Re-run regularly and track customers moving between segments.
- K-Means assumes compact groups; the algorithm comparison is there to check that.

## License

MIT. See `LICENSE`.
