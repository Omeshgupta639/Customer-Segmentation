# Building the same segmentation view in Power BI

The clustering itself is done in Python (scikit-learn). Power BI is used for the interactive visual layer on top of the results. The file to load is **`data/processed/customer_segments.csv`**, which has one row per customer with the `segment` label already attached.

## 1. Load the data
1. Power BI Desktop: **Home > Get data > Text/CSV**, choose `customer_segments.csv`, then **Transform Data**.
2. In Power Query check the types: `signup_date` is Date, `annual_income`, `monetary`, `avg_order_value` are Decimal, `frequency`, `age`, `recency_days` are Whole number. Click **Close & Apply**.

## 2. Add a few measures (Modeling > New measure)
```DAX
Customers = DISTINCTCOUNT(customer_segments[customer_id])
Revenue = SUM(customer_segments[monetary])
Revenue % = DIVIDE([Revenue], CALCULATE([Revenue], ALL(customer_segments[segment])))
Customer % = DIVIDE([Customers], CALCULATE([Customers], ALL(customer_segments[segment])))
Avg Order Value = AVERAGE(customer_segments[avg_order_value])
Avg Recency (days) = AVERAGE(customer_segments[recency_days])
Avg Orders = AVERAGE(customer_segments[frequency])
Discount Use % = AVERAGE(customer_segments[discount_share])
```

## 3. Suggested report page
| Visual | Fields |
|---|---|
| Cards (top row) | Customers, Revenue, Avg Order Value, Avg Recency (days) |
| Slicers | segment, city_tier, gender, acquisition_channel, loyalty_member |
| Clustered bar | Axis: segment. Values: Customer %, Revenue % (shows who the customers are versus where revenue comes from) |
| Scatter | X: recency_days, Y: monetary, Legend: segment, Size: frequency |
| Matrix (heatmap) | Rows: segment. Columns: top_category. Values: Customers. Turn on conditional formatting (background colour) |
| Stacked column | Axis: age bands (create a group on `age`), Legend: segment |
| Table | segment with Avg Orders, Avg Order Value, Avg Recency, Discount Use % |

Use the same colours as the Python charts so the story is consistent: Champions `#0B7A75`, Premium Occasional `#3B5BA9`, Deal Seekers `#E0A100`, New Customers `#7FA032`, At-Risk / Lapsed `#C8553D`.

## 4. Optional: run Python inside Power BI
Power BI can also run Python scripts (Get data > Python script) if Python with pandas and scikit-learn is installed and configured in **Options > Python scripting**. Point it at `data/processed/customer_features.csv`, run the K-Means code from `scripts/02_segmentation.py`, and return the data frame with the `segment` column.
